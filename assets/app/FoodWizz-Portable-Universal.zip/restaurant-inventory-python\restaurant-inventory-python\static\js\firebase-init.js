// Initialize Firebase on the frontend if config is provided
;(function(){
  if (!window.FIREBASE_CONFIG || !window.firebase) return;
  if (!firebase.apps || !firebase.apps.length) {
    firebase.initializeApp(window.FIREBASE_CONFIG);
  }
})();

