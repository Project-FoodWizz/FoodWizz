// Authentication JavaScript for FoodWizz
class AuthManager {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.checkAuthStatus();
    }

    setupEventListeners() {
        // Sign In form
        const signInForm = document.querySelector('.sign-in-container form');
        if (signInForm) {
            signInForm.addEventListener('submit', (e) => this.handleSignIn(e));
        }


        // Password toggle functionality
        this.setupPasswordToggles();

        // Optional: Google sign in via Firebase
        const googleBtn = document.getElementById('googleSignIn');
        if (googleBtn && window.firebase) {
            googleBtn.addEventListener('click', async () => {
                try {
                    const provider = new firebase.auth.GoogleAuthProvider();
                    const result = await firebase.auth().signInWithPopup(provider);
                    const idToken = await result.user.getIdToken();
                    await this.sendIdTokenToBackend(idToken);
                } catch (err) {
                    this.showMessage('Google sign-in failed', 'error');
                    console.error(err);
                }
            });
        }
    }

    setupPasswordToggles() {
        const passwordToggles = document.querySelectorAll('.password-toggle');
        passwordToggles.forEach(toggle => {
            toggle.addEventListener('click', (e) => {
                const input = e.target.parentElement.querySelector('input');
                const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
                input.setAttribute('type', type);
                
                const icon = e.target;
                icon.classList.toggle('ri-eye-off-line');
                icon.classList.toggle('ri-eye-line');
            });
        });
    }

    async handleSignIn(e) {
        e.preventDefault();
        
        const email = document.getElementById('signin-email').value;
        const password = document.getElementById('signin-password').value;
        
        if (!email || !password) {
            this.showMessage('Please fill in all fields', 'error');
            return;
        }

        try {
            // If Firebase is initialized, sign in via Firebase to get idToken
            if (window.firebase && firebase.apps && firebase.apps.length) {
                await firebase.auth().setPersistence(firebase.auth.Auth.Persistence.SESSION);
                await firebase.auth().signInWithEmailAndPassword(email, password);
                const user = firebase.auth().currentUser;
                const idToken = await user.getIdToken();
                await this.sendIdTokenToBackend(idToken);
                return;
            }

            // Fallback: local auth
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();
            
            if (data.success) {
                this.showMessage('Login successful! Redirecting...', 'success');
                setTimeout(() => {
                    window.location.href = '/dashboard';
                }, 1000);
            } else {
                this.showMessage(data.message, 'error');
            }
        } catch (error) {
            this.showMessage('Login failed. Please try again.', 'error');
            console.error('Login error:', error);
        }
    }

    async sendIdTokenToBackend(idToken) {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ idToken })
        });
        const data = await response.json();
        if (data.success) {
            this.showMessage('Login successful! Redirecting...', 'success');
            setTimeout(() => { window.location.href = '/dashboard'; }, 800);
        } else {
            this.showMessage(data.message || 'Login failed', 'error');
        }
    }

    async handleSignUp(e) {
        e.preventDefault();
        
        const name = document.getElementById('signup-name')?.value || '';
        const email = document.getElementById('signup-email').value;
        const password = document.getElementById('signup-password').value;
        
        if (!email || !password) {
            this.showMessage('Please fill in all fields', 'error');
            return;
        }

        if (password.length < 6) {
            this.showMessage('Password must be at least 6 characters', 'error');
            return;
        }

        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    name: name || email.split('@')[0], // Use email prefix if no name provided
                    email, 
                    password 
                })
            });

            const data = await response.json();
            
            if (data.success) {
                this.showMessage('Registration successful! Please sign in.', 'success');
                // Switch to sign in form
                this.switchToSignIn();
            } else {
                this.showMessage(data.message, 'error');
            }
        } catch (error) {
            this.showMessage('Registration failed. Please try again.', 'error');
            console.error('Registration error:', error);
        }
    }

    async checkAuthStatus() {
        try {
            const response = await fetch('/api/auth/check');
            const data = await response.json();
            
            if (data.authenticated) {
                // User is already logged in, redirect to dashboard
                window.location.href = '/dashboard';
            }
        } catch (error) {
            console.error('Auth check error:', error);
        }
    }

    switchToSignIn() {
        const container = document.getElementById('container');
        if (container) {
            container.classList.remove('right-panel-active');
        }
    }

    showMessage(message, type = 'info') {
        // Remove existing messages
        const existingMessages = document.querySelectorAll('.auth-message');
        existingMessages.forEach(msg => msg.remove());

        // Create new message
        const messageDiv = document.createElement('div');
        messageDiv.className = `auth-message auth-message-${type}`;
        messageDiv.textContent = message;
        
        // Style the message
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            border-radius: 4px;
            color: white;
            font-weight: 500;
            z-index: 1000;
            max-width: 300px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            ${type === 'error' ? 'background-color: #e74c3c;' : 
              type === 'success' ? 'background-color: #27ae60;' : 
              'background-color: #3498db;'}
        `;

        document.body.appendChild(messageDiv);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.parentNode.removeChild(messageDiv);
            }
        }, 5000);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AuthManager();
});
